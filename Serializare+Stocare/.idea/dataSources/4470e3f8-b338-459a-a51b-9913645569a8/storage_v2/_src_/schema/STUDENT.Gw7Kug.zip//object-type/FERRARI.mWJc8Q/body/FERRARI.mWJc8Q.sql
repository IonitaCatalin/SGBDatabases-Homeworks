create TYPE BODY Ferrari AS
    OVERRIDING MEMBER PROCEDURE print_valoare IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Valoare vehiculului dumneavoastra este de:'||200000||'$');
    END;
END;
/

