create TYPE Ferrari UNDER Masina
(
    capacitate_cilindrica NUMBER,
    OVERRIDING MEMBER PROCEDURE print_valoare
)NOT FINAL
/

