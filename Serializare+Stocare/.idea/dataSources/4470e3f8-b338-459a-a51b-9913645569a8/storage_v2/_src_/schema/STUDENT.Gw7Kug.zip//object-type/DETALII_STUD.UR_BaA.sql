create TYPE detalii_stud AS OBJECT
(
    nume_stud varchar2(15),
    prenume_stud varchar2(30),
    data_nastere date,
    nr_matricol varchar2(6),
    media NUMBER,
    MEMBER PROCEDURE print_varsta,
    MEMBER FUNCTION update_medie,
    MEMBER PROCEDURE print_pozitie_clasament,
    CONSTRUCTOR FUNCTION detalii_stud RETURN SELF AS RESULT
) NOT FINAL
/

