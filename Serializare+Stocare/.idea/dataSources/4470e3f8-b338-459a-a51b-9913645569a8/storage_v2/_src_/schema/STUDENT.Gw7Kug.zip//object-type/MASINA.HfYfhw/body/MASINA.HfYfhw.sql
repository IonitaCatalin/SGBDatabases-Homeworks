create TYPE BODY Masina AS
    MEMBER PROCEDURE print_valoare IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Valoarea curenta a masinii este de:'||(20000-(nr_kilometrii)*0.1)||' Euro');
    END;
    MEMBER PROCEDURE print_identitate_vehicul IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Masina'||'('||serie||')'||' dumneavoastra a fost produsa de: '||producator||' in anul:'|| data_fabricatie || ' cu motorizarea:'||motorizare || ' si are :'||nr_kilometrii||' kilometriii ');
    END;
    MEMBER PROCEDURE print_uzura IS
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Masina dumneavostra dupa calcule este uzata in proportie de:'||TRUNC(DBMS_RANDOM.VALUE(1,100),2)||'%');
    END;
    MAP MEMBER FUNCTION data_fabricatie_in_zile RETURN NUMBER IS
    BEGIN
        RETURN (SYSDATE-data_fabricatie);
    END;

    CONSTRUCTOR FUNCTION Masina(p_producator VARCHAR2,p_serie VARCHAR2) RETURN SELF AS RESULT
    IS
    BEGIN
        SELF.PRODUCATOR:=p_producator;
        SELF.SERIE:=p_serie;
        SELF.NR_KILOMETRII:=0;
        SELF.data_FABRICATIE:=SYSDATE;
        IF(p_producator='Mercedes')
        THEN
            SELF.MOTORIZARE:='Diesel';
        ELSE
            SELF.MOTORIZARE:='Benzina';
        END IF;
        RETURN;
    END;
END;
/

