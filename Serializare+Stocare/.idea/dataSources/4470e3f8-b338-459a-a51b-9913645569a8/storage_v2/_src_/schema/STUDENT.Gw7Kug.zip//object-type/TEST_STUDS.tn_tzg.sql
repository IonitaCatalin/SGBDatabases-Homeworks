create TYPE test_studs AS OBJECT
    (
        nume   VARCHAR2(15),
        prenume VARCHAR(30)
    )
/

