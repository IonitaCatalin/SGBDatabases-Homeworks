create TYPE Masina AS OBJECT
(
    motorizare VARCHAR2(10),
    producator VARCHAR2(20),
    data_fabricatie DATE,
    nr_kilometrii NUMBER,
    serie VARCHAR2(10),
    NOT FINAL MEMBER PROCEDURE print_valoare,
    MEMBER PROCEDURE print_identitate_vehicul,
    MEMBER PROCEDURE print_uzura,
    MAP MEMBER FUNCTION data_fabricatie_in_zile RETURN NUMBER,
    CONSTRUCTOR FUNCTION Masina(p_producator VARCHAR2,p_serie VARCHAR2) RETURN SELF AS RESULT
) NOT FINAL
/

