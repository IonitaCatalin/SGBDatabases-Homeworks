create TYPE serialized_object_wrapper AS OBJECT
(
    object_id VARCHAR2(55),
    object_instance BLOB
)
/

