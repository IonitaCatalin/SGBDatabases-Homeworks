create PROCEDURE insert_serialized_object_db(new_serialized_obj IN serialized_object_wrapper)
IS
BEGIN
    INSERT INTO store_objects VALUES(table_of_ids.nextval,new_serialized_obj);
END;
/

