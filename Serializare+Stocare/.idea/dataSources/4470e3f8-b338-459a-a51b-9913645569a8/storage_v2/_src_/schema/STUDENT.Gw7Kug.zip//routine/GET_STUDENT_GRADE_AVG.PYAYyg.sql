create FUNCTION get_student_grade_avg(p_nume_stud IN STUDENTI.NUME%TYPE,p_prenume_stud IN STUDENTI.PRENUME%TYPE)
RETURN NUMBER
IS
    v_id_stud STUDENTI.ID%TYPE;
    v_count_stud NUMBER;
    v_count_grades NUMBER;
    v_stud_media NUMBER:=0;
    NO_STUDENT_FOUND EXCEPTION;
    PRAGMA EXCEPTION_INIT(NO_STUDENT_FOUND,-20001);
    NO_GRADES EXCEPTION;
    PRAGMA EXCEPTION_INIT(NO_GRADES,-20002);
BEGIN
    SELECT COUNT(ID) INTO v_count_stud FROM STUDENTI WHERE LOWER(nume)=LOWER(p_nume_stud) AND LOWER(prenume)=LOWER(p_prenume_stud);
    IF v_count_stud<>0
    THEN
        SELECT ID INTO v_id_stud FROM (SELECT ID FROM STUDENTI WHERE LOWER(nume)=LOWER(p_nume_stud) AND LOWER(prenume)=LOWER(p_prenume_stud)) WHERE ROWNUM=1;
        SELECT COUNT(id) INTO v_count_grades FROM NOTE WHERE ID_STUDENT=v_id_stud;
        IF v_count_grades<>0
        THEN
            SELECT AVG(valoare) INTO v_stud_media FROM NOTE WHERE ID_STUDENT=v_id_stud;
            RETURN v_stud_media;
        ELSE
            raise NO_GRADES;
        END IF;
    ELSE
        raise NO_STUDENT_FOUND;
    END IF;
    END;
/

